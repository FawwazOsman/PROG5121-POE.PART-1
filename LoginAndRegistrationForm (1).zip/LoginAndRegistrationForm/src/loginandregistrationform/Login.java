/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginandregistrationform;

/**
 *
 * @author DISD3
 */
import javax.swing.JOptionPane;

public class Login {//Start of class
    
    
    //Declare Variables
    private String FName ;
            
    private String LName;
    
    private String Username;
    
    private String password;
    
    
    boolean checkUserName =false;
    
    boolean checkPassword =false ;
    
    boolean successfulLogin=false ;
    
    //Here you need to call your constructor and the method
    Login(String FirstName ,String LastName ,String UserName , String Password)
   
    
    //LoginAndRegistrationForm constructor
    {
    FName =FirstName;
    LName =LastName;
    Username =UserName;
    password = Password ;
    }
            
}
//___________________________Code Attribution______________
//*Viewd at StackOverFlow
//Author: daddycardona
//Link https://stackoverflow.com/questions/1814814/using-joptionpane


//*Viewd at StackOverFlow
//Author: user42155
//Link https://stackoverflow.com/questions/493233/boolean-expressions-in-java


//*Viewd at StackOverFlow
//Author: Patrick Cassel
//Link https://stackoverflow.com/questions/579445/java-constructors