/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginandregistrationform;

import javax.swing.JOptionPane;

/**
 *
 * @author DISD3
 */
public class LoginAndRegistrationForm {//The beginning of the class

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {//Main Method Begins here
        
        String UserFirstName =JOptionPane.showInputDialog(null, "Enter Your First Name");
        
        String UserLastName =JOptionPane.showInputDialog(null, "Enter Your Last Name");
        
        String UserUserName =JOptionPane.showInputDialog(null, "Enter Your User Name");
        
        String UserPassword =JOptionPane.showInputDialog(null, "Enter Your Password");
        
        
        Login registerUser =new Login(UserFirstName ,UserLastName ,UserUserName ,UserPassword);
        
        boolean verifyUserName =registerUser.checkPassword;
        System.out.println(verifyUserName);
        
    }
      
    
}

//___________________________Code Attribution______________
//*Viewd at StackOverFlow
//Author: daddycardona
//Link https://stackoverflow.com/questions/1814814/using-joptionpane

//*Viewd at StackOverFlow
//Author: m.cekiera
//Link https://stackoverflow.com/questions/28888518/calling-methods-in-java


//*Viewd at StackOverFlow
//Author: Nishant
//Link https://stackoverflow.com/questions/9718314/what-is-string-in-java